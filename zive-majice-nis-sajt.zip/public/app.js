let store={settings:{},products:[]}, cart=JSON.parse(localStorage.getItem("zm_cart")||"[]");
const $=s=>document.querySelector(s), money=n=>new Intl.NumberFormat("sr-RS").format(n)+" RSD";
async function load(){store=await fetch("/api/store").then(r=>r.json()); renderStore();}
function renderStore(){
 $("#heroTitle").innerHTML=(store.settings.hero_title||"Obuci stav.<br>Živi original.").replace(/\n/g,"<br>");
 $("#heroText").textContent=store.settings.hero_text||"";
 $("#ig").href="https://instagram.com/"+(store.settings.instagram||"majce.nis");
 $("#ig").innerHTML="Instagram<br><b>@"+(store.settings.instagram||"majce.nis")+"</b>";
 $("#phone").innerHTML="Telefon<br><b>"+(store.settings.shop_phone||"Kontaktiraj nas")+"</b>";
 $("#year").textContent=new Date().getFullYear();
 $("#products").innerHTML=store.products.map(p=>`<article class="product"><div class="pic">${p.image?`<img src="${p.image}" alt="${esc(p.name)}">`:`<div class="fallback">👕</div>`}</div><div class="pbody"><small>${p.badge||"ŽIVE MAJICE"}</small><h3>${esc(p.name)}</h3><div><span class="price">${money(p.price)}</span>${p.compare_price?`<span class="old">${money(p.compare_price)}</span>`:""}</div><button onclick="openProduct(${p.id})">POGLEDAJ / PORUČI</button></div></article>`).join("") || "<p>Uskoro stižu novi modeli.</p>";
 updateCart();
}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));}
function openProduct(id){const p=store.products.find(x=>x.id===id);$("#modalBody").innerHTML=`<p class="eyebrow">${p.badge||"KOLEKCIJA"}</p><h2>${esc(p.name)}</h2>${p.image?`<img src="${p.image}" style="width:100%;max-height:360px;object-fit:cover;margin:20px 0">`:""}<p style="color:#aaa">${esc(p.description||"")}</p><p class="price">${money(p.price)}</p><div class="form"><label>Veličina<select id="size">${p.sizes.map(x=>`<option>${esc(x)}</option>`).join("")}</select></label><label>Boja<select id="color">${p.colors.map(x=>`<option>${esc(x)}</option>`).join("")}</select></label><label>Količina<input id="qty" type="number" min="1" max="${p.stock}" value="1"></label><button onclick="addCart(${p.id})">DODAJ U KORPU</button></div>`;$("#modal").classList.remove("hidden")}
function addCart(id){const p=store.products.find(x=>x.id===id),size=$("#size").value,color=$("#color").value,qty=Math.min(p.stock,Math.max(1,Number($("#qty").value)));cart.push({product_id:id,name:p.name,price:p.price,size,color,qty});save();closeModal();openCart();}
function save(){localStorage.setItem("zm_cart",JSON.stringify(cart));updateCart()}
function updateCart(){$("#cartCount").textContent=cart.reduce((a,x)=>a+x.qty,0)}
function openCart(){let total=cart.reduce((a,x)=>a+x.price*x.qty,0);$("#modalBody").innerHTML=`<p class="eyebrow">KORPA</p><h2>Tvoja porudžbina</h2>${cart.length?cart.map((x,i)=>`<div class="cart-row"><div><b>${esc(x.name)}</b><br><small>${esc(x.size)} • ${esc(x.color)}</small></div><input type="number" min="1" value="${x.qty}" onchange="cart[${i}].qty=Math.max(1,Number(this.value));save();openCart()"><button onclick="cart.splice(${i},1);save();openCart()">×</button></div>`).join("")+`<div class="total">Ukupno: ${money(total)}</div><form class="form" onsubmit="checkout(event)"><input name="customer_name" placeholder="Ime i prezime *" required><input name="phone" placeholder="Telefon *" required><input name="city" placeholder="Grad"><input name="address" placeholder="Adresa za dostavu"><textarea name="note" placeholder="Napomena"></textarea><button>POŠALJI PORUDŽBINU</button></form>`:"<p>Korpa je prazna.</p>"}`;$("#modal").classList.remove("hidden")}
async function checkout(e){e.preventDefault();const f=new FormData(e.target),data=Object.fromEntries(f);data.items=cart.map(x=>({product_id:x.product_id,size:x.size,color:x.color,qty:x.qty}));const r=await fetch("/api/orders",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)});const j=await r.json();if(!r.ok)return alert(j.error);cart=[];save();$("#modalBody").innerHTML=`<h2>Hvala na porudžbini! 🎉</h2><p>Broj porudžbine je <b>${j.order_no}</b>.</p><p>Javićemo ti se na ostavljeni telefon radi potvrde.</p>`}
function closeModal(){$("#modal").classList.add("hidden")}
$("#cartBtn").onclick=openCart;$("#modal").onclick=e=>{if(e.target.id==="modal")closeModal()};load();
