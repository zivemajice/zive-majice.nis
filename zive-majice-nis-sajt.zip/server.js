const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const bcrypt = require("bcryptjs");
const multer = require("multer");
const Database = require("better-sqlite3");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const uploadDir = path.join(ROOT, "public", "uploads");
fs.mkdirSync(uploadDir, { recursive: true });
fs.mkdirSync(path.join(ROOT, "data"), { recursive: true });

const db = new Database(path.join(ROOT, "data", "shop.db"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 email TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS products (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 slug TEXT UNIQUE NOT NULL,
 description TEXT DEFAULT '',
 price INTEGER NOT NULL,
 compare_price INTEGER DEFAULT 0,
 sizes TEXT DEFAULT 'S,M,L,XL',
 colors TEXT DEFAULT 'Crna',
 stock INTEGER DEFAULT 0,
 image TEXT DEFAULT '',
 featured INTEGER DEFAULT 0,
 badge TEXT DEFAULT '',
 active INTEGER DEFAULT 1,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 order_no TEXT UNIQUE NOT NULL,
 customer_name TEXT NOT NULL,
 phone TEXT NOT NULL,
 city TEXT DEFAULT '',
 address TEXT DEFAULT '',
 note TEXT DEFAULT '',
 total INTEGER NOT NULL,
 status TEXT DEFAULT 'Novo',
 payment_status TEXT DEFAULT 'Nije placeno',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS order_items (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 order_id INTEGER NOT NULL,
 product_id INTEGER,
 product_name TEXT NOT NULL,
 size TEXT,
 color TEXT,
 qty INTEGER NOT NULL,
 price INTEGER NOT NULL,
 FOREIGN KEY(order_id) REFERENCES orders(id)
);
CREATE TABLE IF NOT EXISTS settings (
 key TEXT PRIMARY KEY,
 value TEXT NOT NULL
);
`);

const adminEmail = process.env.ADMIN_EMAIL || "admin@zivemajice.nis";
const adminPassword = process.env.ADMIN_PASSWORD || "PromeniMe-123!";
const existing = db.prepare("SELECT id FROM users WHERE email=?").get(adminEmail);
if (!existing) {
  const hash = bcrypt.hashSync(adminPassword, 12);
  db.prepare("INSERT INTO users(email,password_hash) VALUES(?,?)").run(adminEmail, hash);
}
const defaults = {
  shop_name: process.env.SHOP_NAME || "Žive Majice.Niš",
  shop_phone: process.env.SHOP_PHONE || "",
  instagram: process.env.SHOP_INSTAGRAM || "majce.nis",
  currency: process.env.CURRENCY || "RSD",
  hero_title: "Obuci stav. Živi original.",
  hero_text: "Majice koje nose karakter. Pogledaj novu kolekciju i poruči svoj model.",
};
const set = db.prepare("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)");
for (const [k,v] of Object.entries(defaults)) set.run(k,v);

const upload = multer({
  storage: multer.diskStorage({
    destination: uploadDir,
    filename: (_, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase();
      cb(null, crypto.randomBytes(12).toString("hex") + ext);
    }
  }),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_, file, cb) => {
    cb(null, /^image\/(jpeg|png|webp|avif)$/.test(file.mimetype));
  }
});

app.use(helmet({ crossOriginResourcePolicy: { policy: "cross-origin" } }));
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET || "CHANGE-ME-IN-PRODUCTION",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: false, maxAge: 1000*60*60*8 }
}));
app.use(express.static(path.join(ROOT, "public")));

function settings() {
  return Object.fromEntries(db.prepare("SELECT key,value FROM settings").all().map(x => [x.key,x.value]));
}
function auth(req,res,next) {
  if (!req.session.userId) return res.status(401).json({error:"Niste prijavljeni."});
  next();
}
function slugify(s) {
  return s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"")
    .replace(/[^a-z0-9]+/g,"-").replace(/(^-|-$)/g,"") + "-" + crypto.randomBytes(3).toString("hex");
}
function publicProduct(p) {
  return {...p, sizes: p.sizes.split(",").map(x=>x.trim()).filter(Boolean), colors:p.colors.split(",").map(x=>x.trim()).filter(Boolean)};
}

app.get("/api/store", (req,res) => {
  const s = settings();
  const products = db.prepare("SELECT * FROM products WHERE active=1 ORDER BY featured DESC, created_at DESC").all().map(publicProduct);
  res.json({settings:s, products});
});
app.get("/api/products/:slug", (req,res) => {
  const p = db.prepare("SELECT * FROM products WHERE slug=? AND active=1").get(req.params.slug);
  if (!p) return res.status(404).json({error:"Majica nije pronađena."});
  res.json(publicProduct(p));
});
app.post("/api/orders", (req,res) => {
  const {customer_name, phone, city, address, note="", items=[]} = req.body;
  if (!customer_name || !phone || !Array.isArray(items) || !items.length) return res.status(400).json({error:"Popunite obavezna polja."});
  const tx = db.transaction(() => {
    let total=0; const clean=[];
    for (const item of items) {
      const p = db.prepare("SELECT * FROM products WHERE id=? AND active=1").get(Number(item.product_id));
      const qty = Math.max(1, Math.min(20, Number(item.qty)||1));
      if (!p || p.stock < qty) throw new Error("Neki proizvod više nije dostupan.");
      total += p.price*qty;
      clean.push({p, qty, size:String(item.size||""), color:String(item.color||"")});
    }
    const orderNo = "ZM-" + new Date().toISOString().slice(0,10).replaceAll("-","") + "-" + crypto.randomBytes(3).toString("hex").toUpperCase();
    const r = db.prepare("INSERT INTO orders(order_no,customer_name,phone,city,address,note,total) VALUES(?,?,?,?,?,?,?)")
      .run(orderNo,customer_name,phone,city||"",address||"",note,total);
    const oi = db.prepare("INSERT INTO order_items(order_id,product_id,product_name,size,color,qty,price) VALUES(?,?,?,?,?,?,?)");
    const dec = db.prepare("UPDATE products SET stock=stock-?,updated_at=CURRENT_TIMESTAMP WHERE id=?");
    for (const x of clean) { oi.run(r.lastInsertRowid,x.p.id,x.p.name,x.size,x.color,x.qty,x.p.price); dec.run(x.qty,x.p.id); }
    return orderNo;
  });
  try { res.json({ok:true,order_no:tx()}); } catch(e) { res.status(400).json({error:e.message}); }
});

app.post("/api/login", (req,res) => {
  const u = db.prepare("SELECT * FROM users WHERE email=?").get(req.body.email);
  if (!u || !bcrypt.compareSync(req.body.password||"",u.password_hash)) return res.status(401).json({error:"Pogrešan email ili lozinka."});
  req.session.userId=u.id; req.session.email=u.email; res.json({ok:true,email:u.email});
});
app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/admin/me",auth,(req,res)=>res.json({email:req.session.email}));

app.get("/api/admin/products",auth,(req,res)=>res.json(db.prepare("SELECT * FROM products ORDER BY created_at DESC").all().map(publicProduct)));
app.post("/api/admin/products",auth,upload.single("image"),(req,res)=>{
  const b=req.body; if(!b.name || !b.price) return res.status(400).json({error:"Naziv i cena su obavezni."});
  const image=b.image_url || (req.file ? "/uploads/"+req.file.filename : "");
  const slug=slugify(b.name);
  const r=db.prepare(`INSERT INTO products(name,slug,description,price,compare_price,sizes,colors,stock,image,featured,badge,active)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`).run(b.name,slug,b.description||"",Number(b.price),Number(b.compare_price||0),b.sizes||"S,M,L,XL",b.colors||"Crna",Number(b.stock||0),image,Number(b.featured||0),b.badge||"",Number(b.active===undefined?1:b.active));
  res.json({ok:true,id:r.lastInsertRowid});
});
app.put("/api/admin/products/:id",auth,upload.single("image"),(req,res)=>{
  const old=db.prepare("SELECT * FROM products WHERE id=?").get(req.params.id); if(!old) return res.status(404).json({error:"Nije pronađeno."});
  const b=req.body; const image=b.image_url || (req.file ? "/uploads/"+req.file.filename : old.image);
  db.prepare(`UPDATE products SET name=?,description=?,price=?,compare_price=?,sizes=?,colors=?,stock=?,image=?,featured=?,badge=?,active=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`)
   .run(b.name,b.description||"",Number(b.price),Number(b.compare_price||0),b.sizes||"S,M,L,XL",b.colors||"Crna",Number(b.stock||0),image,Number(b.featured||0),b.badge||"",Number(b.active===undefined?1:b.active),req.params.id);
  res.json({ok:true});
});
app.delete("/api/admin/products/:id",auth,(req,res)=>{db.prepare("DELETE FROM products WHERE id=?").run(req.params.id);res.json({ok:true});});

app.get("/api/admin/orders",auth,(req,res)=>{
  const orders=db.prepare("SELECT * FROM orders ORDER BY created_at DESC").all();
  for(const o of orders) o.items=db.prepare("SELECT * FROM order_items WHERE order_id=?").all(o.id);
  res.json(orders);
});
app.put("/api/admin/orders/:id",auth,(req,res)=>{
  db.prepare("UPDATE orders SET status=?,payment_status=? WHERE id=?").run(req.body.status||"Novo",req.body.payment_status||"Nije placeno",req.params.id);
  res.json({ok:true});
});
app.get("/api/admin/stats",auth,(req,res)=>{
  const products=db.prepare("SELECT COUNT(*) n FROM products WHERE active=1").get().n;
  const orders=db.prepare("SELECT COUNT(*) n FROM orders").get().n;
  const revenue=db.prepare("SELECT COALESCE(SUM(total),0) n FROM orders WHERE status NOT IN ('Otkazano')").get().n;
  const newOrders=db.prepare("SELECT COUNT(*) n FROM orders WHERE status='Novo'").get().n;
  res.json({products,orders,revenue,newOrders});
});
app.get("/api/admin/settings",auth,(req,res)=>res.json(settings()));
app.put("/api/admin/settings",auth,(req,res)=>{
  const stmt=db.prepare("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value");
  for(const [k,v] of Object.entries(req.body)) stmt.run(k,String(v));
  res.json({ok:true});
});
app.put("/api/admin/password",auth,(req,res)=>{
  if(!req.body.password || req.body.password.length<10) return res.status(400).json({error:"Lozinka mora imati najmanje 10 karaktera."});
  db.prepare("UPDATE users SET password_hash=? WHERE id=?").run(bcrypt.hashSync(req.body.password,12),req.session.userId);
  res.json({ok:true});
});

app.get("/admin",(req,res)=>res.sendFile(path.join(ROOT,"public","admin.html")));
app.get("*",(req,res)=>res.sendFile(path.join(ROOT,"public","index.html")));

app.listen(PORT,()=>console.log(`Žive Majice.Niš radi na http://localhost:${PORT}`));
