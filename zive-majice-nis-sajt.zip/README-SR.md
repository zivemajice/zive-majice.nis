# Žive Majice.Niš — kompletan sajt

Ovo je kompletna početna verzija online prodavnice sa javnim sajtom i privatnim vlasničkim panelom.

## Šta postoji

- Javni katalog majica
- Fotografije proizvoda
- Cene, stare cene, veličine, boje, stanje
- Oznake NOVO / BESTSELLER / AKCIJA
- Korpa
- Poručivanje bez registracije kupca
- Evidencija porudžbina
- Promena statusa porudžbine
- Admin panel koji je zaštićen prijavom
- Dodavanje i izmena majica preko slike/fajla
- Skriveni proizvodi
- Podešavanje naziva, telefona, Instagrama i naslovne poruke
- Promena vlasničke lozinke
- SQLite baza
- Sigurnosni headeri preko Helmet-a

## Pokretanje na računaru

Potrebno je Node.js 20+.

1. Raspakuj projekat.
2. Otvori terminal u folderu projekta.
3. Pokreni:

   npm install

4. Kopiraj `.env.example` u `.env`.
5. Obavezno promeni `ADMIN_PASSWORD` i `SESSION_SECRET`.
6. Pokreni:

   npm start

7. Otvori:
   http://localhost:3000

   Vlasnički panel:
   http://localhost:3000/admin

## Važno za javni internet

Da bi ljudi mogli da pristupe sajtu, projekat treba postaviti na server/hosting. Za ozbiljan rad preporučujem VPS ili hosting koji podržava Node.js, HTTPS i trajni disk.

Za produkciju:
- `SESSION_SECRET` mora biti dugačak i nasumičan.
- `ADMIN_PASSWORD` mora biti jaka i jedinstvena.
- HTTPS treba uključiti.
- `secure: true` treba podesiti u session cookie kada je sajt na HTTPS-u.
- Backup foldera `data/` treba raditi redovno.
- Upload direktorijum treba zaštititi od izvršavanja fajlova.
- Za veći promet preporučuje se PostgreSQL/S3 ili slična produkciona infrastruktura.

## Domen

Možeš kupiti domen, npr. `zivemajice.rs`, i povezati DNS sa hostingom. Tačan postupak zavisi od hostinga koji izaberemo.

## Online plaćanje

U ovoj verziji porudžbina se šalje kao "plaćanje pouzećem / naknadna potvrda". Za kartice treba otvoriti nalog kod payment procesora i ubaciti njihove API ključeve. U `.env` su ostavljena mesta za Stripe ključeve, ali kartično plaćanje nije uključeno dok ne dobiješ stvarne ključeve i uslove procesora.

## Sledeći produkcioni koraci

1. Izabrati domen i hosting.
2. Postaviti sajt online.
3. Podesiti HTTPS.
4. Postaviti prave podatke za kontakt.
5. Ubaciti logo i prve fotografije majica.
6. Podesiti dostavu i način plaćanja.
7. Testirati porudžbinu od početka do kraja.
8. Po želji dodati kartično plaćanje, automatske email/SMS obaveštenja, kupon kodove, analitiku i napredniju evidenciju zaliha.
